// Golf Tournament Management System using Doubly Linked List
#include <iostream>
#include <string>
using namespace std;

class Player {
public:
    string name;
    int score;
    Player* prev;
    Player* next;

    Player(string n, int s) {
        name = n;
        score = s;
        prev = NULL;
        next = NULL;
    }
};

class Tournament {
public:
    Player* head;

    Tournament() {
        head = NULL;
    }

    void addPlayer(string name, int score) {
        Player* newPlayer = new Player(name, score);
        if (head == NULL || score < head->score) { // Insert at beginning
            newPlayer->next = head;
            if (head != NULL) head->prev = newPlayer;
            head = newPlayer;
            return;
        }

        Player* current = head;
        while (current->next != NULL && current->next->score <= score) {
            current = current->next;
        }

        newPlayer->next = current->next;
        if (current->next != NULL) current->next->prev = newPlayer;
        newPlayer->prev = current;
        current->next = newPlayer;
    }

    void deletePlayer(string name) {
        Player* current = head;

        while (current != NULL && current->name != name) {
            current = current->next;
        }

        if (current == NULL) {
            cout << "Player not found!\n";
            return;
        }

        if (current->prev != NULL) current->prev->next = current->next;
        if (current->next != NULL) current->next->prev = current->prev;

        if (current == head) head = current->next;

        delete current;
        cout << "Player deleted successfully!\n";
    }

    void displayAll() {
        Player* temp = head;
        while (temp != NULL) {
            cout << temp->name << " (Score: " << temp->score << ")\n";
            temp = temp->next;
        }
    }

    void displayLowestScore() {
        if (head == NULL) {
            cout << "No players found!\n";
            return;
        }
        cout << "Player with lowest score: " << head->name << " (Score: " << head->score << ")\n";
    }

    void displayByScore(int score) {
        Player* temp = head;
        bool found = false;
        while (temp != NULL) {
            if (temp->score == score) {
                cout << temp->name << " (Score: " << temp->score << ")\n";
                found = true;
            }
            temp = temp->next;
        }
        if (!found) cout << "No players with score " << score << " found!\n";
    }

    void displayBackwardFrom(string name) {
        Player* temp = head;

        while (temp != NULL && temp->name != name) {
            temp = temp->next;
        }

        if (temp == NULL) {
            cout << "Player not found!\n";
            return;
        }

        while (temp != NULL) {
            cout << temp->name << " (Score: " << temp->score << ")\n";
            temp = temp->prev;
        }
    }
};

int main() {
    Tournament tournament;
    int choice, score;
    string name;

    while (true) {
        cout << "\n--- Golf Tournament System ---\n";
        cout << "1. Add Player\n2. Delete Player\n3. Display All\n4. Display Lowest Score\n5. Display Players with Same Score\n6. Display Backward From a Player\n7. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter player name: ";
            cin >> name;
            cout << "Enter player score: ";
            cin >> score;
            tournament.addPlayer(name, score);
            break;

        case 2:
            cout << "Enter player name to delete: ";
            cin >> name;
            tournament.deletePlayer(name);
            break;

        case 3:
            tournament.displayAll();
            break;

        case 4:
            tournament.displayLowestScore();
            break;

        case 5:
            cout << "Enter score to search: ";
            cin >> score;
            tournament.displayByScore(score);
            break;

        case 6:
            cout << "Enter player name to display backward from: ";
            cin >> name;
            tournament.displayBackwardFrom(name);
            break;

        case 7:
            return 0;

        default:
            cout << "Invalid choice!\n";
        }
    }

    return 0;
}

