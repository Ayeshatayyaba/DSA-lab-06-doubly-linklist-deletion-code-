// Doubly Linked List Deletion in C++
#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* prev;
    Node* next;

    Node(int value) {
        data = value;
        prev = NULL;
        next = NULL;
    }
};

class DoublyLinkedList {
public:
    Node* head;

    DoublyLinkedList() {
        head = NULL;
    }

    void insertAtEnd(int value) {
        Node* newNode = new Node(value);

        if (head == NULL) {
            head = newNode;
            return;
        }

        Node* temp = head;
        while (temp->next != NULL) {
            temp = temp->next;
        }

        temp->next = newNode;
        newNode->prev = temp;
    }

    void deleteAtBeginning() {
        if (head == NULL) {
            cout << "List is empty!" << endl;
            return;
        }

        Node* temp = head;
        head = head->next;
        if (head != NULL) {
            head->prev = NULL;
        }

        delete temp;
        cout << "Node at beginning deleted successfully." << endl;
    }

    void deleteAfter(int value) {
        if (head == NULL) {
            cout << "List is empty!" << endl;
            return;
        }

        Node* temp = head;

        while (temp != NULL && temp->data != value) {
            temp = temp->next;
        }

        if (temp == NULL || temp->next == NULL) {
            cout << "No node found after the given value." << endl;
            return;
        }

        Node* nodeToDelete = temp->next;
        temp->next = nodeToDelete->next;

        if (nodeToDelete->next != NULL) {
            nodeToDelete->next->prev = temp;
        }

        delete nodeToDelete;
        cout << "Node after value " << value << " deleted successfully." << endl;
    }

    void display() {
        Node* temp = head;
        while (temp != NULL) {
            cout << temp->data << " <-> ";
            temp = temp->next;
        }
        cout << "NULL" << endl;
    }
};

int main() {
    DoublyLinkedList dll;

    // Inserting nodes
    dll.insertAtEnd(1);
    dll.insertAtEnd(45);
    dll.insertAtEnd(60);
    dll.insertAtEnd(12);

    cout << "Original List: ";
    dll.display();

    // a) Deleting node at beginning
    dll.deleteAtBeginning();
    cout << "After deleting beginning node: ";
    dll.display();

    // b) Deleting node after value 45
    dll.deleteAfter(45);
    cout << "After deleting node after 45: ";
    dll.display();

    return 0;
}

